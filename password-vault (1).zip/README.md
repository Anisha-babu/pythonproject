# Password Vault and Generator

A simple yet secure Python application to generate strong passwords and store them in an encrypted local vault. Ideal for personal password management.

## Features

- Strong, random password generation
- Encrypted storage of credentials using Fernet symmetric encryption
- Secure storage in a local JSON file
- CLI interface (GUI version available)

## Technologies Used

- Python 3.x
- `cryptography` for encryption
- `tkinter` (optional GUI)
- JSON for data storage

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/password-vault.git
   cd password-vault
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the app:
   ```bash
   python main.py
   ```

## Optional GUI

To launch the GUI version:
```bash
python gui.py
```

## File Structure

```
password-vault/
│
├── main.py           # CLI interface
├── vault.py          # Encryption and storage logic
├── generator.py      # Password generation
├── gui.py            # Optional GUI interface (tkinter)
├── key.key           # Encryption key (auto-generated)
├── vault.json        # Encrypted credential storage
├── requirements.txt  # Dependencies
└── README.md         # Project overview
```

## Security Tips

- Do **not** upload `key.key` or `vault.json` to public repositories.
- Add them to `.gitignore`:
  ```
  key.key
  vault.json
  ```

## License

MIT License