import tkinter as tk
from tkinter import messagebox
from generator import generate_password
from vault import *

if not os.path.exists("key.key"):
    write_key()
key = load_key()

def save_entry():
    site = site_entry.get()
    username = username_entry.get()
    password = password_entry.get()

    if not password:
        password = generate_password()
        password_entry.insert(0, password)
    
    encrypted = encrypt_data(password, key).decode()
    data = load_passwords()
    data[site] = {"username": username, "password": encrypted}
    save_passwords(data)

    messagebox.showinfo("Saved", "Credentials saved securely.")
    site_entry.delete(0, tk.END)
    username_entry.delete(0, tk.END)
    password_entry.delete(0, tk.END)

app = tk.Tk()
app.title("Password Vault")

tk.Label(app, text="Site").grid(row=0, column=0)
tk.Label(app, text="Username").grid(row=1, column=0)
tk.Label(app, text="Password").grid(row=2, column=0)

site_entry = tk.Entry(app)
username_entry = tk.Entry(app)
password_entry = tk.Entry(app)

site_entry.grid(row=0, column=1)
username_entry.grid(row=1, column=1)
password_entry.grid(row=2, column=1)

tk.Button(app, text="Save", command=save_entry).grid(row=3, column=0, columnspan=2)

app.mainloop()