from generator import generate_password
from vault import *

def main():
    if not os.path.exists("key.key"):
        write_key()
    key = load_key()
    
    passwords = load_passwords()
    
    site = input("Enter site name: ")
    username = input("Enter username: ")
    password = input("Enter password (leave blank to generate): ")
    
    if not password:
        password = generate_password()
        print(f"Generated password: {password}")
    
    encrypted_password = encrypt_data(password, key)
    passwords[site] = {"username": username, "password": encrypted_password.decode()}
    
    save_passwords(passwords)
    print("Password saved securely.")

if __name__ == "__main__":
    main()